"""
Package for CSE2201_Web_Project.
"""
